#pragma once

/// <summary>
/// Enemy��HPUI (View)
/// </summary>
class EnemyUiHp
{
public:
	void Draw(const EnemyParam& param);
};

